// basics
#include <stdio.h>
#include <cs50.h>

int main(void)
{
    // User input
    float user_input;
    do
    {
        user_input = get_float("How much do you owe? : ");
    }
    while (user_input <= 0);

    // Official statement of how much you owe
    printf("You owe the customer $%.2f\n", user_input);

    // Value of Left Over Change Variables
    int TotalCents = user_input * 100;
    int LOAQ = (TotalCents % 25);
    int LOAD = ((TotalCents % 25) % 10);
    int LOAN = (((TotalCents % 25) % 10) % 5);
    int LOAP = ((((TotalCents % 25) % 10) % 5) % 1);

    // Calculations of Left Over Coins
    int Qrts = (TotalCents - LOAQ) / 25;
    int Dms = (LOAQ - LOAD) / 10;
    int Nckl = (LOAD - LOAN) / 5;
    int Pnny = (LOAN - LOAP) / 1;

    // Printing what you owe
    printf("");
    printf("--------");
    printf("\n");

    printf("Quarters Owed : %i\n", Qrts);
    printf("Dimes Owed : %i\n", Dms);
    printf("Nickels Owed : %i\n", Nckl);
    printf("Pennies Owed : %i\n", Pnny);
    printf("Total coins owed : %i\n", Qrts + Dms + Nckl + Pnny);
    printf("\n");
}